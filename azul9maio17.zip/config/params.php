<?php

return [
    'adminEmail' => 'moronilemes@live.com',
];
