<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=zizap',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8',
];

//return [
//    'class' => 'yii\db\Connection',
//    'dsn' => 'mysql:host=localhost;dbname=id1200306_spazul',
//    'username' => 'id1200306_root',
//    'password' => 'fatec2017',
//    'charset' => 'utf8',
//];
